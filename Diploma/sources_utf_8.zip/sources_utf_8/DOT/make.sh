dot string_of_childs.dot -Tpdf -o ../string_of_childs.pdf
#rem dot sample_for_label_syntax_tree.dot -Tpdf -o sample_for_label_syntax_tree.pdf

#rem dot sample_for_label_diriv_tree_with_labels.dot -Tpdf -o sample_for_label_diriv_tree_with_labels.pdf

#rem dot sample_for_label_diriv_tree_extracted.dot -Tpdf -o sample_for_label_diriv_tree_extracted.pdf

#rem dot sample_for_label_general.dot -Tpdf -o sample_for_label_general.pdf

#rem dot sample_for_label_general_ru.dot -Tpdf -o ../sample_for_label_general_ru.pdf
#rem dot sample_for_label_general_ru.dot -Tpdf -o ../../temp_20_febr/sample_for_label_general_ru.pdf

dot general_tool_structure.dot -Tpdf -o ../general_tool_structure.pdf
