pdflatex --shell-escape presentation.tex
evince  presentation.pdf &
